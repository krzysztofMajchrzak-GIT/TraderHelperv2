import axios from 'axios';

const useAxios = () => {
    const apiBaseURL = `http://127.0.0.1:8000/api`;

    const axiosInstance = axios.create({
        baseURL: apiBaseURL,
    });

    return axiosInstance;
};

export default useAxios;
